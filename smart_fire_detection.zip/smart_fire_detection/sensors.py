"""
sensors.py
----------
Simulated sensors for the prototype (no hardware needed).

In a real system, generate_readings() would be replaced by code that reads
values from an ESP32/Arduino (see the README for how to do that).
"""

import numpy as np

# The four sensors used everywhere in the project.
SENSOR_NAMES = ["temperature", "smoke", "flame", "humidity"]

# Friendly names and units, used by the dashboard.
SENSOR_LABELS = {
    "temperature": "Temperature",
    "smoke": "Smoke",
    "flame": "Flame",
    "humidity": "Humidity",
}
SENSOR_UNITS = {"temperature": "°C", "smoke": "ppm", "flame": "%", "humidity": "%"}

# Possible health states of a sensor (simulated with sidebar selectboxes).
HEALTH_STATES = ["Connected", "Disconnected", "Faulty", "Unresponsive"]

# Demo scenarios so you can show every severity level on demand.
SCENARIOS = [
    "Normal",
    "Smoke rising (Warning)",
    "Developing fire (Danger)",
    "Full fire (Critical)",
]

# For each scenario: (temperature factor, smoke factor, flame range).
# The factors are multiplied by the environment's threshold, so
# 1.3 means "30% above the safe limit".
_SCENARIO_SETTINGS = {
    SCENARIOS[0]: (0.55, 0.30, (0, 5)),
    SCENARIOS[1]: (0.60, 1.30, (0, 5)),
    SCENARIOS[2]: (1.15, 1.60, (5, 15)),
    SCENARIOS[3]: (1.80, 3.50, (85, 100)),
}

_rng = np.random.default_rng()  # random number generator


def generate_readings(scenario, base_thresholds):
    """Return a dict of realistic random sensor values for the chosen scenario."""
    temp_factor, smoke_factor, flame_range = _SCENARIO_SETTINGS[scenario]

    # Small random noise (about ±3%) so the numbers wiggle like real sensors.
    def noise():
        return _rng.normal(1.0, 0.03)

    readings = {
        "temperature": base_thresholds["temperature"] * temp_factor * noise(),
        "smoke": base_thresholds["smoke"] * smoke_factor * noise(),
        "flame": _rng.uniform(*flame_range),
        "humidity": float(np.clip(_rng.normal(50, 4), 5, 95)),
    }
    return {name: round(float(value), 1) for name, value in readings.items()}


def apply_health(readings, health):
    """
    Hide readings from sensors that are not 'Connected'.
    An unavailable sensor gives None instead of a number.
    """
    return {
        name: (value if health[name] == "Connected" else None)
        for name, value in readings.items()
    }
