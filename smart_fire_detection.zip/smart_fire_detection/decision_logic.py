"""
decision_logic.py
-----------------
Combines several sensor readings into ONE fire severity level.
No single sensor decides everything (except extreme values, see below).
"""

LEVELS = ["Normal", "Warning", "Danger", "Critical"]
LEVEL_ICONS = {"Normal": "🟢", "Warning": "🟡", "Danger": "🟠", "Critical": "🔴"}

# Safe limits for each environment.
# temperature / smoke / flame: values ABOVE the limit are unsafe.
# humidity_min: values BELOW the limit mean very dry air (higher fire risk).
DEFAULT_THRESHOLDS = {
    "Home":       {"temperature": 45, "smoke": 300, "flame": 30, "humidity_min": 25},
    "Kitchen":    {"temperature": 60, "smoke": 450, "flame": 30, "humidity_min": 20},
    "Laboratory": {"temperature": 40, "smoke": 250, "flame": 25, "humidity_min": 25},
    "Factory":    {"temperature": 70, "smoke": 600, "flame": 35, "humidity_min": 15},
}

# Which threshold key belongs to which sensor.
THRESHOLD_KEY = {
    "temperature": "temperature",
    "smoke": "smoke",
    "flame": "flame",
    "humidity": "humidity_min",
}

# "Very high" rules used for the Critical level.
VERY_HIGH_TEMP_FACTOR = 1.5   # 50% above the temperature limit
VERY_HIGH_SMOKE_FACTOR = 3.0  # 3x the smoke limit
VERY_HIGH_FLAME = 80          # strong flame signal (0-100 scale)

NAMES = {
    "temperature": "Temperature",
    "smoke": "Smoke/gas",
    "flame": "Flame",
    "humidity": "Low humidity",
}
SINGLE_MESSAGES = {
    "temperature": "High temperature detected",
    "smoke": "High smoke level detected",
    "flame": "Flame detected",
    "humidity": "Air is unusually dry",
}


def _join(words):
    """['a','b','c'] -> 'a, b and c'"""
    if len(words) <= 2:
        return " and ".join(words)
    return ", ".join(words[:-1]) + " and " + words[-1]


def evaluate(readings, thresholds):
    """
    readings   : dict of sensor values (None = sensor unavailable)
    thresholds : dict of safe limits
    Returns    : {"level": ..., "triggered": [...], "reason": "..."}
    """
    triggered = []   # sensors beyond their safe limit
    very_high = []   # sensors far beyond their limit

    temp, smoke = readings.get("temperature"), readings.get("smoke")
    flame, hum = readings.get("flame"), readings.get("humidity")

    # Step 1: compare each AVAILABLE sensor with its threshold.
    if temp is not None:
        if temp > thresholds["temperature"]:
            triggered.append("temperature")
        if temp >= thresholds["temperature"] * VERY_HIGH_TEMP_FACTOR:
            very_high.append("temperature")
    if smoke is not None:
        if smoke > thresholds["smoke"]:
            triggered.append("smoke")
        if smoke >= thresholds["smoke"] * VERY_HIGH_SMOKE_FACTOR:
            very_high.append("smoke")
    if flame is not None:
        if flame > thresholds["flame"]:
            triggered.append("flame")
        if flame >= VERY_HIGH_FLAME:
            very_high.append("flame")
    if hum is not None and hum < thresholds["humidity_min"]:
        triggered.append("humidity")

    names = [NAMES[s] for s in triggered]

    # Step 2: combine the results into a severity level.
    flame_plus_other = "flame" in triggered and (
        "temperature" in triggered or "smoke" in triggered
    )
    if very_high or flame_plus_other:
        level = "Critical"
        if very_high:
            reason = "Very high " + _join([NAMES[s].lower() for s in very_high]) + " detected."
        else:
            reason = "Flame detected together with " + _join(
                [NAMES[s].lower() for s in triggered if s != "flame"]
            ) + " above safe limits."
    elif len(triggered) >= 2:
        level = "Danger"
        reason = _join(names) + " levels are above safe limits."
    elif len(triggered) == 1:
        level = "Warning"
        reason = SINGLE_MESSAGES[triggered[0]] + "."
    else:
        level = "Normal"
        reason = "All available sensor readings are within safe limits."

    return {"level": level, "triggered": triggered, "reason": reason}


def suggest_actions(result):
    """Return (fan_suggested, pump_suggested) based on the evaluation."""
    fan = "smoke" in result["triggered"]   # smoke/gas high -> ventilate
    pump = result["level"] == "Critical"   # critical fire -> water pump
    return fan, pump
