"""
app.py - Smart Fire Detection and Alert System (PROTOTYPE)
Run with:  streamlit run app.py
Everything here is SIMULATED: no physical sensors, fans or pumps are used.
"""

import time
from datetime import datetime

import pandas as pd
import streamlit as st

import alerts
import camera_detection
import decision_logic as logic
import sensors

st.set_page_config(page_title="Smart Fire Detection", page_icon="🔥", layout="wide")

# ---------------------------------------------------------------
# 1. Session state = memory that survives each refresh of the page
# ---------------------------------------------------------------
defaults = {
    "history": [],            # alert history (list of dicts)
    "last_level": "Normal",   # previous severity, used to avoid duplicate logs
    "acknowledged": None,     # severity level the user has acknowledged
    "readings_log": [],       # recent readings for the chart
    "fan_on": False,
    "pump_on": False,
}
for key, value in defaults.items():
    st.session_state.setdefault(key, value)


# Button callbacks (they run BEFORE the page reruns).
def acknowledge_alarm(level):
    st.session_state.acknowledged = level


def turn_on(key):
    st.session_state[key] = True


# ---------------------------------------------------------------
# 2. Sidebar: environment, thresholds, simulation controls
# ---------------------------------------------------------------
st.sidebar.header("⚙️ Settings")
environment = st.sidebar.selectbox("Environment", list(logic.DEFAULT_THRESHOLDS))
base = logic.DEFAULT_THRESHOLDS[environment]

scenario = st.sidebar.selectbox("Simulation scenario", sensors.SCENARIOS)

st.sidebar.subheader("Safe thresholds")
# The key includes the environment so sliders reset to that environment's defaults.
thresholds = {
    "temperature": st.sidebar.slider("Max temperature (°C)", 20, 120, base["temperature"], key=f"t_{environment}"),
    "smoke": st.sidebar.slider("Max smoke/gas (ppm)", 100, 1500, base["smoke"], step=10, key=f"s_{environment}"),
    "flame": st.sidebar.slider("Max flame signal (%)", 5, 80, base["flame"], key=f"f_{environment}"),
    "humidity_min": st.sidebar.slider("Min humidity (%)", 5, 60, base["humidity_min"], key=f"h_{environment}"),
}

st.sidebar.subheader("Simulate sensor problems")
health = {
    name: st.sidebar.selectbox(f"{sensors.SENSOR_LABELS[name]} sensor", sensors.HEALTH_STATES, key=f"health_{name}")
    for name in sensors.SENSOR_NAMES
}

st.sidebar.subheader("Live updates")
auto_refresh = st.sidebar.toggle("Auto-refresh", value=True)
interval = st.sidebar.slider("Refresh every (seconds)", 1, 10, 3)
st.sidebar.caption("Turn auto-refresh off while using the camera.")

# ---------------------------------------------------------------
# 3. Read sensors and make a decision
# ---------------------------------------------------------------
raw = sensors.generate_readings(scenario, base)      # simulated values
readings = sensors.apply_health(raw, health)         # hide failed sensors
result = logic.evaluate(readings, thresholds)        # combine sensors
level, reason = result["level"], result["reason"]
fan_suggested, pump_suggested = logic.suggest_actions(result)

# Keep the last 60 readings (as % of threshold) for the chart.
def pct(value, limit):
    return None if value is None else round(100 * value / limit, 1)

st.session_state.readings_log.append({
    "Temperature": pct(readings["temperature"], thresholds["temperature"]),
    "Smoke": pct(readings["smoke"], thresholds["smoke"]),
    "Flame": pct(readings["flame"], thresholds["flame"]),
})
st.session_state.readings_log = st.session_state.readings_log[-60:]

# Log to history when severity changes; reset acknowledgement when safe again.
if alerts.should_log(st.session_state.last_level, level):
    st.session_state.history.insert(0, alerts.make_record(level, reason, result["triggered"]))
if level in ("Normal", "Warning"):
    st.session_state.acknowledged = None
st.session_state.last_level = level

# ---------------------------------------------------------------
# 4. Dashboard header and severity banner
# ---------------------------------------------------------------
st.title("🔥 Smart Fire Detection and Alert System")
st.caption(f"Prototype with simulated data  |  Environment: **{environment}**  |  {datetime.now():%H:%M:%S}")

icon = logic.LEVEL_ICONS[level]
st.subheader(f"Current severity: {icon} {level}")
banner = f"{icon} {level}: {reason}"
if level == "Normal":
    st.success(banner)
elif level == "Warning":
    st.warning(banner)
else:
    st.error(banner)

# Alarm block for Danger / Critical.
if level in ("Danger", "Critical"):
    if st.session_state.acknowledged != level:
        st.error(f"🚨 ALARM ({level.upper()}): {reason}")
        st.write("Triggered by:", ", ".join(logic.NAMES[s] for s in result["triggered"]))
        st.button("✅ Acknowledge Alarm", on_click=acknowledge_alarm, args=(level,))
    else:
        st.info(f"Alarm acknowledged, but the situation is still **{level}**.")

# ---------------------------------------------------------------
# 5. Sensor readings
# ---------------------------------------------------------------
st.header("📟 Sensor Readings")
columns = st.columns(4)
for col, name in zip(columns, sensors.SENSOR_NAMES):
    label, unit = sensors.SENSOR_LABELS[name], sensors.SENSOR_UNITS[name]
    limit = thresholds[logic.THRESHOLD_KEY[name]]
    value = readings[name]
    with col:
        if value is None:
            st.metric(label, "N/A", delta="sensor unavailable", delta_color="off")
            st.progress(0.0, text="No data")
        else:
            flag = "⚠️ " if name in result["triggered"] else ""
            limit_text = f"min {limit}{unit}" if name == "humidity" else f"limit {limit}{unit}"
            st.metric(flag + label, f"{value} {unit}", delta=limit_text, delta_color="off")
            fraction = value / 100 if name == "humidity" else value / limit
            st.progress(min(max(fraction, 0.0), 1.0), text=f"{fraction * 100:.0f}%")

st.caption("Trend as % of each safe limit (100% = threshold)")
chart_data = pd.DataFrame(st.session_state.readings_log)
st.line_chart(chart_data)

# ---------------------------------------------------------------
# 6. Sensor health
# ---------------------------------------------------------------
st.header("🩺 Sensor Health")
health_icons = {"Connected": "✅", "Disconnected": "❌", "Faulty": "⚠️", "Unresponsive": "⏳"}
for col, name in zip(st.columns(4), sensors.SENSOR_NAMES):
    col.write(f"**{sensors.SENSOR_LABELS[name]}**")
    col.write(f"{health_icons[health[name]]} {health[name]}")
for message in alerts.sensor_fault_messages(health):
    st.warning(message)

# ---------------------------------------------------------------
# 7. Fan / pump control (simulated)
# ---------------------------------------------------------------
st.header("🌀 Fan & Water Pump Control (simulated)")
st.caption("These toggles only change on-screen state. No real device is switched.")
fan_col, pump_col = st.columns(2)
with fan_col:
    st.toggle("Fan ON/OFF", key="fan_on")
    st.write("Fan is ON 🌀" if st.session_state.fan_on else "Fan is OFF")
    if fan_suggested and not st.session_state.fan_on:
        st.warning("Suggestion: turn the Fan ON (smoke/gas is high).")
        st.button("Apply suggestion", key="apply_fan", on_click=turn_on, args=("fan_on",))
with pump_col:
    st.toggle("Water Pump ON/OFF", key="pump_on")
    st.write("Pump is ON 💧" if st.session_state.pump_on else "Pump is OFF")
    if pump_suggested and not st.session_state.pump_on:
        st.error("Suggestion: turn the Water Pump ON (critical fire conditions).")
        st.button("Apply suggestion", key="apply_pump", on_click=turn_on, args=("pump_on",))

# ---------------------------------------------------------------
# 8. Camera detection (optional demo)
# ---------------------------------------------------------------
st.header("📷 Camera Detection (optional demo)")
st.caption("Simple colour-based demo using OpenCV. NOT production-ready: it can give false alarms and miss real fires.")
photo = st.camera_input("Take a photo")
if photo is None:
    photo = st.file_uploader("...or upload an image to test", type=["jpg", "jpeg", "png"])

if photo is not None:
    image = camera_detection.decode_image(photo)
    detection = camera_detection.analyze_image(image)
    img_col, info_col = st.columns(2)
    img_col.image(photo, caption="Camera image")
    with info_col:
        if detection["flame"]:
            st.error("🔥 Possible Flame Detected")
        if detection["smoke"]:
            st.warning("🌫️ Possible Smoke Detected")
        if not detection["flame"] and not detection["smoke"]:
            st.success("✅ No Visible Fire Detected")
        st.write(f"Flame-coloured pixels: {detection['flame_ratio'] * 100:.1f}%")
        st.write(f"Smoke-like pixels: {detection['smoke_ratio'] * 100:.1f}%")

# ---------------------------------------------------------------
# 9. Alert history
# ---------------------------------------------------------------
st.header("📜 Alert History")
if st.session_state.history:
    st.dataframe(alerts.history_to_dataframe(st.session_state.history), use_container_width=True)
    if st.button("Clear history"):
        st.session_state.history = []
        st.rerun()
else:
    st.info("No alerts yet.")

# ---------------------------------------------------------------
# 10. How to connect real hardware
# ---------------------------------------------------------------
with st.expander("🔌 How to connect real sensors later (ESP32/Arduino)"):
    st.markdown(
        """
- **Temperature/humidity:** DHT22 or DS18B20 on an ESP32/Arduino.
- **Smoke/gas:** MQ-2 / MQ-135 analog sensor (needs warm-up and calibration).
- **Flame:** IR flame sensor module.
- **Fan/pump:** relay module driven by a GPIO pin (use a proper power supply).
- **Send data:** the board sends JSON over USB serial (`pyserial`) or WiFi (HTTP/MQTT).
- **In this project:** replace `sensors.generate_readings()` with a function that returns the same dictionary.

See README.md for a full example.
"""
    )

# ---------------------------------------------------------------
# 11. Auto-refresh: wait, then rerun the script for new readings
# ---------------------------------------------------------------
if auto_refresh:
    time.sleep(interval)
    st.rerun()
