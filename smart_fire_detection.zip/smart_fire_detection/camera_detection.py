"""
camera_detection.py
-------------------
A VERY SIMPLE computer-vision demo using colour analysis with OpenCV.

!! NOT production-ready !!  It only looks at colours, so it can be fooled by
orange objects, sunsets, lamps, white walls, fog, etc. It must never be the
only safety system. Replace analyze_image() with a trained AI model later.
"""

import cv2
import numpy as np

# Fractions of the image that must match a colour range to raise a detection.
FLAME_RATIO_LIMIT = 0.02   # 2% of pixels look like bright orange/yellow
SMOKE_RATIO_LIMIT = 0.35   # 35% of pixels look grey and hazy


def decode_image(uploaded_file):
    """Convert a Streamlit camera/upload file into an OpenCV (BGR) image."""
    data = np.frombuffer(uploaded_file.getvalue(), np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def detect_with_colour_rules(image_bgr):
    """Basic method: count pixels whose colour looks like flame or smoke."""
    small = cv2.resize(image_bgr, (320, 240))       # smaller = faster
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)    # HSV makes colour rules easier

    # Flame: orange/yellow hue, strongly coloured and very bright.
    flame_mask = cv2.inRange(hsv, np.array([0, 120, 200]), np.array([35, 255, 255]))
    # Smoke: any hue, but LOW colour saturation and medium brightness (greyish).
    smoke_mask = cv2.inRange(hsv, np.array([0, 0, 90]), np.array([180, 50, 220]))

    flame_ratio = cv2.countNonZero(flame_mask) / flame_mask.size
    smoke_ratio = cv2.countNonZero(smoke_mask) / smoke_mask.size

    return {
        "flame": flame_ratio > FLAME_RATIO_LIMIT,
        "smoke": smoke_ratio > SMOKE_RATIO_LIMIT,
        "flame_ratio": flame_ratio,
        "smoke_ratio": smoke_ratio,
        "flame_mask": flame_mask,
    }


def detect_with_ai_model(image_bgr):
    """
    PLACEHOLDER for a trained fire/smoke model (e.g. YOLO or a CNN).
    It should return the same dictionary keys as detect_with_colour_rules():
    flame (bool), smoke (bool), flame_ratio, smoke_ratio, flame_mask.
    """
    raise NotImplementedError("No AI model installed yet.")


def analyze_image(image_bgr):
    """Single entry point used by app.py. Swap the method here later."""
    # return detect_with_ai_model(image_bgr)   # <- enable when a model exists
    return detect_with_colour_rules(image_bgr)
