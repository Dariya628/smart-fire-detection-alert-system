"""
alerts.py
---------
Helpers for the alert history and for sensor-fault messages.
The history is just a Python list of dicts (kept in Streamlit's session_state).
"""

from datetime import datetime

import pandas as pd

from sensors import SENSOR_LABELS


def should_log(last_level, new_level):
    """Log only when the level CHANGES to something other than Normal
    (otherwise the history would fill up with duplicates every refresh)."""
    return new_level != "Normal" and new_level != last_level


def make_record(level, reason, triggered):
    """Create one history entry."""
    return {
        "Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Severity": level,
        "Reason": reason,
        "Sensors": ", ".join(triggered) if triggered else "-",
    }


def history_to_dataframe(history):
    """Turn the list of records into a Pandas table for display."""
    return pd.DataFrame(history, columns=["Time", "Severity", "Reason", "Sensors"])


def sensor_fault_messages(health):
    """Return a warning text for every sensor that is not 'Connected'."""
    verbs = {
        "Disconnected": "is disconnected",
        "Faulty": "is faulty",
        "Unresponsive": "is not responding",
    }
    messages = []
    for name, state in health.items():
        if state != "Connected":
            messages.append(f"Warning: {SENSOR_LABELS[name]} sensor {verbs[state]}.")
    return messages
