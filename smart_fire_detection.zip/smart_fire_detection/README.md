# 🔥 Smart Fire Detection and Alert System (Prototype)

A beginner-friendly Streamlit dashboard that combines several **simulated** sensors to decide a fire severity level. It runs on a laptop with no hardware.

> ⚠️ Educational prototype only. It is **not** a certified fire-safety product. Never rely on it to protect people or property.

## Project structure

```
smart_fire_detection/
├── app.py               # Streamlit dashboard (UI)
├── sensors.py           # Simulated sensors + sensor health
├── decision_logic.py    # Multi-sensor rules and thresholds
├── camera_detection.py  # Simple OpenCV demo + AI-model placeholder
├── alerts.py            # Alert history + sensor fault messages
├── requirements.txt
└── README.md
```

## Installation

```bash
cd smart_fire_detection
python -m venv venv
# Windows:  venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

Your browser opens at http://localhost:8501.

## How to demonstrate

1. Pick an **Environment** in the sidebar (thresholds change).
2. Pick a **Simulation scenario** to show Normal → Warning → Danger → Critical.
3. Adjust threshold **sliders** to see the decision change.
4. Set a sensor to *Unresponsive*, *Faulty* or *Disconnected* to see the health warning.
5. In Danger/Critical, click **Acknowledge Alarm**, then check **Alert History**.
6. Try the fan/pump suggestions (simulated only).
7. Turn **Auto-refresh** off, then use the camera or upload a photo.

## Multi-sensor decision logic

Each available sensor is compared with its threshold. Temperature, smoke and flame are "triggered" when **above** the limit; humidity is triggered when **below** its minimum (dry air).

| Level | Rule |
|---|---|
| 🟢 Normal | No sensor triggered |
| 🟡 Warning | Exactly one sensor triggered |
| 🟠 Danger | Two or more sensors triggered |
| 🔴 Critical | Any very high value (temperature ≥ 1.5× limit, smoke ≥ 3× limit, flame ≥ 80%), **or** flame plus temperature/smoke triggered |

Notes:
- Sensors that are disconnected, faulty or unresponsive are **ignored** and reported in the health section.
- The dashboard always lists which sensors caused the alert.
- Fan is suggested when smoke/gas is high; the pump is suggested at Critical.
- Camera results are shown separately and do not change the severity in this prototype.

## Sample output (what you will see)

- **Normal:** green banner "All available sensor readings are within safe limits." Four metric cards with progress bars, a flat trend chart, all sensors ✅ Connected, and "No alerts yet."
- **Warning:** yellow banner "High smoke level detected." The Smoke card is marked ⚠️ and its bar is full. A suggestion to turn the fan ON appears.
- **Danger:** orange severity label with a red alarm box "Temperature and smoke/gas levels are above safe limits.", an **Acknowledge Alarm** button, and a new row in Alert History.
- **Critical:** red banner "Very high temperature, smoke/gas and flame detected." The pump-ON suggestion appears.
- **Sensor failure:** yellow message "Warning: Smoke sensor is not responding." and the Smoke card shows N/A.
- **Camera:** the photo appears with "Possible Flame Detected", "Possible Smoke Detected" or "No Visible Fire Detected" and the pixel percentages.

## Connecting real hardware later (ESP32/Arduino)

| Part | Example hardware | Notes |
|---|---|---|
| Temperature/humidity | DHT22, DS18B20 | Digital sensors |
| Smoke/gas | MQ-2, MQ-135 | Analog; needs warm-up and calibration |
| Flame | IR flame sensor | Analog/digital output |
| Fan / pump | Relay module + fan/pump | Use correct power supply; never switch mains without proper safety |

**Option A: USB serial.** The board prints one JSON line, for example `{"temperature": 31.2, "smoke": 210, "flame": 2, "humidity": 48}`. On the PC:

```python
import json, serial  # pip install pyserial

port = serial.Serial("COM3", 115200, timeout=2)  # Linux/macOS: "/dev/ttyUSB0"

def read_real_sensors():
    line = port.readline().decode().strip()
    return json.loads(line)  # same dictionary format as generate_readings()
```

Then use `read_real_sensors()` in `app.py` instead of `sensors.generate_readings()`.

**Option B: WiFi.** The ESP32 sends the same JSON by HTTP or MQTT to a small server, and the dashboard reads the latest values.

**Controlling fan/pump:** send commands such as `FAN_ON` back to the board (serial/MQTT) and switch a relay pin. Keep a hardware fail-safe on the device.

## Future improvements

- **Real sensors:** calibration, averaging/filtering to reduce false alarms, timeouts to detect dead sensors automatically.
- **Mobile control:** responsive web app, or a mobile app talking to a small API.
- **Database:** store readings and alerts in SQLite/PostgreSQL for reports and charts.
- **Notifications:** SMS, email, WhatsApp/Telegram, push notifications, and a physical buzzer.
- **AI camera model:** train or use a fire/smoke detector (e.g. YOLO) and plug it into `detect_with_ai_model()` in `camera_detection.py`; feed camera results into `decision_logic.py`.
- **Safety:** user login, escalation if an alarm is not acknowledged, and independent hardware safety cut-offs.

## Limitations

- All sensor data is random and simulated.
- Camera detection uses colour rules only and can give false alarms or miss fires.
- Auto-refresh reruns the page; turn it off while using the camera.
